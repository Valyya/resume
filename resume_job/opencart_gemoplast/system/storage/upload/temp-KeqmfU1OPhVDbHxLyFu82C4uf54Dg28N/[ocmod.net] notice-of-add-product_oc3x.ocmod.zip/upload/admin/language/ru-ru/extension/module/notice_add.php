<?php
// Heading
$_['heading_title']    = 'Уведомления при добавлении <a href="https://prowebber.ru/" target="_blank" title="PROWEBBER" style="color:#0362B6;margin-right:5px"><i class="fa fa-cloud-download fa-fw"></i></a> ';

// Text
$_['text_extension']   = 'Модули';
$_['text_success']     = 'Настройки модуля обновлены!';
$_['text_edit']        = 'Редактирование модуля';

// Entry
$_['entry_status']     = 'Статус';
$_['layout_noty']      = 'Схема';


$_['layout_bottomRight']  = 'Снизу справа';
$_['layout_bottomLeft']   = 'Снизу слева';
$_['layout_bottomCenter'] = 'Снизу в центре';
$_['layout_bottom'] 	  = 'Снизу';

$_['layout_center']    	  = 'В центре';
$_['layout_centerRight']  = 'В центре справа';
$_['layout_centerLeft']   = 'В центре слева';

$_['layout_top']          = 'Сверху';
$_['layout_topRight']     = 'Сверху справа';
$_['layout_topLeft']      = 'Сверху слева';
$_['layout_topCenter']    = 'Сверху в центре';

$_['noty_timeout']    = '1000, 3000, 3500, 5000, и т.д. Задержка для закрытия события в миллисекундах (мс).';


// Error
$_['error_permission'] = 'У вас нет прав для управления этим модулем!';


